
## ------------------------------------------------------------------------
require(RSQLAlchemy)
mySession=session()


## ------------------------------------------------------------------------
testDB
testEngine=engine(databaseName=testDB)
mySession$bind(testEngine)


## ------------------------------------------------------------------------
mySession$query("snp") #prints entire table
#mySession$query("snp.snp_id")#prints snp_id column in snp table
#mySession$query("snp","snp.snp_id")


## ------------------------------------------------------------------------
mySession$query("snp.snp_id")$limit()[1:5,]
mySession$query("snp.snp_id")$offset()[5:10,]


## ------------------------------------------------------------------------
mySession$query("snp")$orderBy("all_A")
mySession$query("snp")$orderBy("all_A","all_B")#sort by multiple columns


## ------------------------------------------------------------------------
mySession$query("snp")$filterBy(all_A=="A") #equals
mySession$query("snp")$filterBy(all_A!="A") #not equals
#mySession$query("snp")$filterBy(snp_id %like% "1") #like
#mySession$query("snp")$filterBy(snp_id %!like% "1") #not like
#mySession$query("snp")$filterBy(all_A %in% c("A","C")) #in
#mySession$query("snp")$filterBy(all_A %!in% c("A","C")) #not in
#mySession$query("snp")$filterBy(is.null(all_A)) #is null
#mySession$query("snp")$filterBy(!is.null(all_A)) #is not null
#mySession$query("snp")$filterBy(all_A=="A" | all_A=="C")#or
#mySession$query("snp")$filterBy(all_A=="A" & all_B=="C")#and
#mySession$query("snp","genotype")$filterBy(snp.snp_id==genotype.snp_id)#multiple tables


## ------------------------------------------------------------------------
mySession$join("snp","genotype")$limit()[1:3,] #outerjoin
#mySession$outerjoin("snp","genotype.genotype")
#mySession$join("snp","genotype")$filterBy(snp.snp_id==genotype.snp_id)
#mySession$innerjoin("snp","genotype",joinOn="snp.snp_id==genotype.snp_id")
#mySession$leftjoin("snp","genotype",joinOn="snp.snp_id==genotype.snp_id")
#mySession$rightjoin("snp","genotype",joinOn="snp.snp_id==genotype.snp_id")


## ------------------------------------------------------------------------
snp<-mapTable(tableName="snp",
              columns='snp_id="character",chr="character",all_A="character",all_B="character"',
             primaryKey="snp_id");
snp 
#create an instance of snp
SNP50 <- snp(snp_id='SNP50', chr="1", all_A="T", all_B="C")

#access the attributes of instances like any other reference classes
SNP50$snp_id
SNP50$all_A
SNP50$primaryKey


## ------------------------------------------------------------------------
#check contents of session
length(mySession$objects);names(mySession$objects);mySession$objects

#add an object to session
mySession$add(SNP50)
length(mySession$objects);names(mySession$objects);mySession$objects

#modify object and resave to session
SNP50$snp_id<-"SNPCHANGE"
mySession$add(SNP50)#object previously added to session is replaced
length(mySession$objects);names(mySession$objects);mySession$objects

#add multiple objects at once
SNPA <- snp(snp_id='SNPA', chr="1", all_A="T", all_B="C")
SNPB <- snp(snp_id='SNPB', chr="1", all_A="T", all_B="C")
mySession$add_all(SNPA,SNPB)
length(mySession$objects);names(mySession$objects);mySession$objects

#delete object(s) from session
length(mySession$objects);names(mySession$objects)
mySession$delete(SNP50)
length(mySession$objects);names(mySession$objects)
mySession$delete_all(SNPA,SNPB)
length(mySession$objects);names(mySession$objects)


## ------------------------------------------------------------------------
mySession$query("snp")
SNPINSERT <- snp(snp_id='SNPINSERT', chr="1", all_A="T", all_B="C")
mySession$add(SNPINSERT)
mySession$commit()
mySession$query("snp")


